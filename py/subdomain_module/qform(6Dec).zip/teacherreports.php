<?php
   
/* Database credentials. Assuming you are running MySQL, server with default setting (user 'root' with no password) */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'qform');

echo "<head>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1'>";

echo"<style type='text/css'>";

//Below use for top banner
echo"body {";
echo"margin-left: 0px;";
echo"margin-top: 0px;";
echo"margin-right: 0px;";
echo"margin-bottom: 0px;";
echo"}";

//Below use for submit button
echo ".block {";
echo "display: block;";
echo "width: 25%;";
echo "border: none;";
echo "background-color: blue;";
echo "color: white;";
echo "padding: 14px 28px;";
echo "font-size: 20px;";
echo "cursor: pointer;";
echo "text-align: center;";
echo "}";

echo ".block:hover {";
echo "background-color: '#ddd'";
echo "color: black;";
echo "}";

//Below use for animate button
echo "a:link, a:visited {";
echo "background-color: #67DBC8;";
echo "color: black;";
echo "border: 4px solid green;";
echo "padding: 10px 20px;";
echo "text-align: center;";
echo "text-decoration: none;";
echo "display: inline-block;";
echo "}";
      
echo "a:hover, a:active {";
echo "background-color: green;";
echo "color: white;";
echo "}";

//Below use for big radio button
echo "input[type=radio] {";
echo "border: 0px;";
echo "width: 50%;";
echo "height: 2em;";
echo "}";

echo "a:link, a:visited {";
echo "background-color: #67DBC8;";
echo "color: black;";
echo "border: 4px solid green;";
echo "padding: 10px 20px;";
echo "text-align: center;";
echo "text-decoration: none;";
echo "display: inline-block;";
echo "}";
      
echo "a:hover, a:active {";
echo "background-color: green;";
echo "color: white;";
echo "}";

echo "</style>";

echo "<script>";
echo "function validateForm() {";
echo "let reflectcontents = document.forms['reflectform']['reflection'].value;";
echo "if (reflectcontents == '') { alert('反思內容空白不能送出 ，請檢查檢清楚，謝謝! '); return false; }; }";
echo "</script>";

echo "</head>";

echo"<body background='images/bg_wall.png'>";

echo "<table width='100%'  border='0'>";
echo "<tr>";
echo "<td height='123' colspan='2' background='images/titlebrick.jpg'><img src='images/gslc_logo.png' width='113' height='106' align='left' />";
echo "<h2><strong>&nbsp;&nbsp;Gertrude Simon Lutheran College </strong></h2>";
echo "<h2><strong>&nbsp;&nbsp;2021-2022</strong></h2></td>";
echo "</tr>";
echo "<tr>";
echo "<td height='66' align='center'><h2>路德會西門英才中學</h2></td>";
echo "<td align='center'><h2>學生教與學問卷調查</h2></td>";
echo "</tr>";
echo "<tr>";
echo "<td colspan='2'><center>引言 : 教學過程是提高學與教效能的關鍵。";
echo "</center>";
echo "<center>";
echo "本問卷的目的是要收集同學對個人學習及對教師教學方面的意見、從而提昇師生學與教的質素。";
echo "</center></td>";
echo "</tr>";
echo "<tr>";
echo "<td height='15' colspan='2' background='images/titlebrick.jpg'>&nbsp;</td>";
echo "</tr>";
echo "</table>";

/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
    
// Check connection
if($link === false){
   die("ERROR: Could not connect. " . mysqli_connect_error());
}

//Find the chinese name in the table 'users' by use login name
$cookiename = $_COOKIE["namecookie"];
$cookiepin = $_COOKIE["pincookie"]; //copy the pin cookie to a variable
    
//SQL query for search corresponding chinese name of login name
$sqladmin = "select *from users where name = '$cookiename' and pin = '$cookiepin'"; 
$resultadmin = mysqli_query($link, $sqladmin);  
$row = mysqli_fetch_array($resultadmin, MYSQLI_ASSOC);  
$count = mysqli_num_rows($resultadmin);

$stdno = $row['stdno'];  $chname = $row['chname']; //Read the field stdno and chname in the table "users" and assign it to the variables $stdno and $chname

if($count == 1 && $stdno == "0"){  //If find the current login info in the DB table and user is not student account

    echo "<H2>教與學網上問卷統計數據:</H2>";

    if ($cookiename == "teacher") { 
        $teacher = $_POST['teacher']; 
        //$teacher = "溫舜雄"; //For test only

    } //Received the admin staff passed the teacher name if login is the admin user
    
    
    if ($cookiename != "teacher") 
    { 
        $teacher = $chname; //Received the chinese name of login teacher read from the "users" DB table      
    } 

    $totalmarks = 0; //Total marks for a teacher with all subject the teacher taught    
    $countsub = 0 ; //Count the number of the specific
    $subjectitems = array(); //set the variable $subjectitem to array
    $selfteachskill = array();  //set the variable $selfteachskill to array
    //$schoutcomeavg = array(); //set the variable $schoutcomeavg to array
    $no = 1; //Use for the arrary number of the variable "subjectitems" and other data (e.g. outcome, skill, etc...)
        
        //After insert a set of new data to the table, read the all records from the table
        $sqlteacher = "SELECT * FROM teachers where teacher1 = '$teacher' OR teacher2 = '$teacher' OR teacher3 = '$teacher' OR teacher4 = '$teacher' OR teacher5 = '$teacher' OR teacher6 = '$teacher' OR 
        teacher7 = '$teacher' OR teacher8 = '$teacher' OR teacher9 = '$teacher' OR teacher10 = '$teacher' OR teacher11 = '$teacher' OR teacher12 = '$teacher' OR teacher13 = '$teacher' OR teacher14 = '$teacher' 
        OR teacher15 = '$teacher'";
        
        $result0 = $link->query($sqlteacher);          

        //Admin account allow select to see different teachers survey results
        if ($cookiename == "teacher") {
        echo "以下是<B><font size = '5'> [" . $teacher . "] </font></B>老師所有任教的科目: " ." ". "<a href='selectteacher.php'><B>選擇老師</B></a>"  . " " . "<a href='selectsubjects.php'>
        <B>管理員主頁</B></a>" ." ". "<a href='logout.php'><B>登出系統</B></a><BR>";
        }

        //Teacher account (not admin) just allow to logout
        if ($cookiename != "teacher") { echo "以下是<B><font size = '5'> [" . $teacher . "] </font></B>老師所有任教的科目: <a href='changepin.php'><B>更改密碼</B></a>" ." ". "<a href='logout.php'><B>登出系統</B></a><BR>";}

        if ($result0->num_rows > 0) {    
           
            while($row0 = $result0->fetch_assoc()) {
    
           //Find the teacher teach the subject and class row by row in the DB table "teachers"
           $grade = $row0['grade'];
           $teachsub = $row0['teachsub'];
           
           /*//Below codes reserved for change to average after for another codes write to DB table
           $q1sum = $rowno['SUM(q1)'];$q2sum = $rowno['SUM(q2)'];$q3sum = $rowno['SUM(q3)'];$q4sum = $rowno['SUM(q4)'];$q5sum = $rowno['SUM(q5)'];$q6sum = $rowno['SUM(q6)'];$q7sum = $rowno['SUM(q7)'];$q8sum = $rowno['SUM(q8)'];
           $q9sum = $rowno['SUM(q9)'];$q10sum = $rowno['SUM(q10)'];$q11sum = $rowno['SUM(q11)'];$q12sum = $rowno['SUM(q12)'];$q13sum = $rowno['SUM(q13)'];$q14sum = $rowno['SUM(q14)'];$q15sum = $rowno['SUM(q15)'];
           $q16sum = $rowno['SUM(q16)'];$q17sum = $rowno['SUM(q17)'];$q18sum = $rowno['SUM(q18)'];$q19sum = $rowno['SUM(q19)'];$q20sum = $rowno['SUM(q20)']; $q21sum = $rowno['SUM(q21)']; $q22sum = $rowno['SUM(q22)'];
           $q23sum = $rowno['SUM(q23)'];$q24sum = $rowno['SUM(q24)'];$q25sum = $rowno['SUM(q25)'];$q26sum = $rowno['SUM(q26)'];$q27sum = $rowno['SUM(q27)']; $q28sum = $rowno['SUM(q28)']; $q29sum = $rowno['SUM(q29)'];
           $q30sum = $rowno['SUM(q30)'];$q31sum = $rowno['SUM(q31)'];$q32sum = $rowno['SUM(q32)'];$q33sum = $rowno['SUM(q33)'];$q34sum = $rowno['SUM(q34)']; $q35sum = $rowno['SUM(q35)']; $q36sum = $rowno['SUM(q36)'];
           $q37sum = $rowno['SUM(q37)'];$q38sum = $rowno['SUM(q38)'];$q39sum = $rowno['SUM(q39)'];$q40sum = $rowno['SUM(q40)'];$q41sum = $rowno['SUM(q41)'];
           
           //Sum of total questions marks
           $allqsum = $q1sum+$q2sum+$q3sum+$q4sum+$q5sum+$q6sum+$q7sum+$q8sum+$q9sum+$q10sum+$q11sum+$q12sum+$q13sum+$q14sum+$q15sum+$q16sum+$q17sum+$q18sum+$q19sum+$q20sum;
           $q21sum+$q22sum+$q23sum+$q24sum+$q25sum+$q26sum+$q27sum+$q28sum+$q29sum+$q30sum+$q31sum+$q32sum+$q33sum+$q34sum+$q35sum+$q36sum+$q37sum+$q38sum+$q39sum+$q40sum+$q41sum;
           $totalmarks = $totalmarks + $allqsum; //accumulate the marks for all subject(s)
           */
           
           //Read the teachers in the record for each subject, the codes for write the each question mark to the DB table
           $sqlteachers = "SELECT teacher1, teacher2, teacher3, teacher4, teacher5, teacher6, teacher7, teacher8, teacher9, teacher10, teacher11, teacher12, teacher13, teacher14, teacher15 FROM qrecords WHERE subjects = '$teachsub' AND qtype ='Compulsory' AND class = '$grade'";
           $resultteachers = mysqli_query($link, $sqlteachers);  
           $rowno1 = mysqli_fetch_array($resultteachers, MYSQLI_ASSOC);
           $teacher1 = $rowno1["teacher1"];  $teacher2 = $rowno1["teacher2"];$teacher3 = $rowno1["teacher3"];  $teacher4 = $rowno1["teacher4"]; $teacher5 = $rowno1["teacher5"];  $teacher6 = $rowno1["teacher6"];
           $teacher7 = $rowno1["teacher7"];  $teacher8 = $rowno1["teacher8"];$teacher9 = $rowno1["teacher9"];  $teacher10 = $rowno1["teacher10"]; $teacher11 = $rowno1["teacher11"];  $teacher12 = $rowno1["teacher12"]; $teacher13 = $rowno1["teacher13"];  $teacher14 = $rowno1["teacher14"]; $teacher15 = $rowno1["teacher15"];          
                     
           //Use variable store the form of each subject
           $grades[$no] = $grade;           
           
           /*
           //Select the specific teacher and class for insert or update  all subject reports to to another DB table for one specific teacher
           $sqlreport = "SELECT * FROM reports WHERE subjects = '$teachsub' AND class = '$grade' AND teacher1 = '$teacher' OR teacher2 = '$teacher' OR teacher3 = '$teacher' OR teacher4 = '$teacher' OR teacher5 = '$teacher' OR teacher6 = '$teacher' OR teacher7 = '$teacher' OR teacher8 = '$teacher' OR teacher9 = '$teacher' 
           OR teacher10 = '$teacher' OR teacher11 = '$teacher' OR teacher12 = '$teacher' OR teacher13 = '$teacher' OR teacher14 = '$teacher' OR teacher15 = '$teacher'";
           $resultreport = $link->query($sqlreport);

           //Update the records in the table "reports"
           if ($resultreport->num_rows > 0) {
               while($row = $resultreport->fetch_assoc()) {
                  $sqlreport = "UPDATE reports SET q1 = '$q1sum', q2 = '$q2sum', q3 = '$q3sum',  q4 = '$q4sum', q5 = '$q5sum', q6 = '$q6sum', q7 = '$q7sum', q8 = '$q8sum', q9 = '$q9sum', q10 = '$q10sum', q11 = '$q11sum', q12 = '$q13sum', q14 = '$q14sum', q15 = '$q15sum', q16 = '$q16sum', q17 = '$q17sum', q18 = '$q18sum', 
                  q19 = '$q19sum', q20 = '$q20sum', q21 = '$q21sum', q22 = '$q23sum', q24 = '$q24sum',  q25 = '$q25sum', q26 = '$q26sum', q27 = '$q27sum', q28 = '$q28sum', q29 = '$q29sum', q30 = '$q30sum', q31 = '$q31sum', q32 = '$q32sum', q33 = '$q33sum', q34 = '$q34sum', q35 = '$q35sum', q36 = '$q36sum', q37 = '$q37sum', q38 = '$q38sum', 
                  q39 = '$q39sum', q40 = '$q40sum', q41 = '$q41sum'  WHERE subjects = '$teachsub' AND class = '$grade' AND teacher1 = '$teacher' OR teacher2 = '$teacher' OR teacher3 = '$teacher' OR teacher4 = '$teacher' OR teacher5 = '$teacher' OR teacher6 = '$teacher' OR teacher7 = '$teacher' OR teacher8 = '$teacher' OR teacher9 = '$teacher' 
                  OR teacher10 = '$teacher' OR teacher11 = '$teacher' OR teacher12 = '$teacher' OR teacher13 = '$teacher' OR teacher14 = '$teacher' OR teacher15 = '$teacher'";
               }
           }
           
           //Insert a new report to the table "reports"
           if ($resultreport->num_rows == 0)
           {
               $sqlreport = "INSERT INTO reports (class, subjects, q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11, q12, q13, q14, q15, q16, q17, q18, q19, q20, q21, q22, q23, q24, q25, q26, q27, q28, q29, q30, q31, q32, q33, q34, q35, q36, q37, q38, q39, q40, q41, teacher1, teacher2, teacher3, teacher4, teacher5, teacher6, teacher7, 
               teacher8, teacher9, teacher10, teacher11, teacher12, teacher13, teacher14, teacher15 ) VALUES ('$grade', '$teachsub', '$q1sum', '$q2sum', '$q3sum', '$q4sum', '$q5sum', '$q6sum', '$q7sum', '$q8sum', '$q9sum', '$q10sum', '$q11sum', '$q12sum', '$q13sum', '$q14sum', '$q15sum', '$q16sum', '$q17sum', '$q18sum', '$q19sum',
               '$q20sum', '$q21sum', '$q22sum', '$q23sum', '$q24sum', '$q25sum', '$q26sum', '$q27sum', '$q28sum', '$q29sum', '$q30sum', '$q31sum', '$q32sum', '$q33sum', '$q34sum', '$q35sum', '$q36sum', '$q37sum', '$q38sum', '$q39sum', '$q40sum', '$q41sum', '$teacher1', '$teacher2', '$teacher3', '$teacher4', '$teacher5', '$teacher6',
               '$teacher7', '$teacher8', '$teacher9', '$teacher10', '$teacher11', '$teacher12', '$teacher13', '$teacher14', '$teacher15')";
           }           
           $resultreport = mysqli_query($link, $sqlreport);
           */


           //To get the average value of different question, 教學技巧[個人]成績統計, q3 q7 q8 q11 q17 q19 q20 q22 q23 q27 q28 q34, output the personal average marks of specific subject
           $sqlavgrec = "SELECT AVG(q3), AVG(q7), AVG(q8), AVG(q11), AVG(q17), AVG(q19), AVG(q20), AVG(q22), AVG(q23), AVG(q27), AVG(q28), AVG(q34) FROM qrecords where subjects = '$teachsub' AND class = '$grade'"; 
           $resultavgrec = mysqli_query($link, $sqlavgrec);   
           $rowavg = mysqli_fetch_array($resultavgrec, MYSQLI_ASSOC);

           $avgq3 = $rowavg['AVG(q3)']; $avgq7 = $rowavg['AVG(q7)']; $avgq8 = $rowavg['AVG(q8)']; $avgq11 = $rowavg['AVG(q11)']; $avgq17 = $rowavg['AVG(q17)']; $avgq19 = $rowavg['AVG(q19)'];
           $avgq20 = $rowavg['AVG(q20)']; $avgq22 = $rowavg['AVG(q22)']; $avgq23 = $rowavg['AVG(q23)']; $avgq27 = $rowavg['AVG(q27)']; $avgq28 = $rowavg['AVG(q28)']; $avgq34 = $rowavg['AVG(q34)']; 
           
           //Use the array variable $selfteachskill to store the self teach skill marks for each own subject
           $selfteachskill[$no] = ($avgq3+$avgq7+$avgq8+$avgq11+$avgq17+$avgq19+$avgq20+$avgq22+$avgq23+$avgq27+$avgq28+$avgq34)/12; //Fixed 12 questions for teaching skill
           $selfteachavg = $selfteachskill[$no]; //copy the arrary variable to a varibale for write to the 'allreports' table

           //To get the average value of different question, 教學技巧[科組平均分]成績統計, q3 q7 q8 q11 q17 q19 q20 q22 q23 q27 q28 q34, output the personal average marks of specific subject
           $sqlsubavg = "SELECT AVG(q3), AVG(q7), AVG(q8), AVG(q11), AVG(q17), AVG(q19), AVG(q20), AVG(q22), AVG(q23), AVG(q27), AVG(q28), AVG(q34) FROM qrecords where subjects = '$teachsub'"; 
           $resultsubavg = mysqli_query($link, $sqlsubavg);   
           $rowsubavg = mysqli_fetch_array($resultsubavg, MYSQLI_ASSOC);

           $subavgq3 = $rowsubavg['AVG(q3)']; $subavgq7 = $rowsubavg['AVG(q7)']; $subavgq8 = $rowsubavg['AVG(q8)']; $subavgq11 = $rowsubavg['AVG(q11)']; $subavgq17 = $rowsubavg['AVG(q17)']; $subavgq19 = $rowsubavg['AVG(q19)'];
           $subavgq20 = $rowsubavg['AVG(q20)']; $subavgq22 = $rowsubavg['AVG(q22)']; $subavgq23 = $rowsubavg['AVG(q23)']; $subavgq27 = $rowsubavg['AVG(q27)']; $subavgq28 = $rowsubavg['AVG(q28)']; $subavgq34 = $rowsubavg['AVG(q34)']; 
           
           //Use the array variable $subavg to store the self teach skill marks for all same subject group
           $subavg[$no] = ($subavgq3+$subavgq7+$subavgq8+$subavgq11+$subavgq17+$subavgq19+$subavgq20+$subavgq22+$subavgq23+$subavgq27+$subavgq28+$subavgq34)/12; //Fixed 12 questions for teaching skill
           $subjectavg =  $subavg[$no]; //copy the arrary variable to a varibale for write to the 'allreports' table
           
           //Under testing, Group the same form classes to one level 
           if($grade == '1A' || $grade == '1B' || $grade == '1C' || $grade == '1D') { $level = 1;} if($grade == '2A' || $grade == '2B' || $grade == '2C' || $grade == '2D') { $level = 2;}
           if($grade == '3A' || $grade == '3B' || $grade == '3C' || $grade == '3D') { $level = 3;} if($grade == '4A' || $grade == '4B' || $grade == '4C' || $grade == '4D') { $level = 4;}
           if($grade == '5A' || $grade == '5B' || $grade == '5C' || $grade == '5D') { $level = 5;} if($grade == '6A' || $grade == '6B' || $grade == '6C' || $grade == '6D') { $level = 6;}
           
           //To get the average value of different question, 教學技巧[班級平均分]成績統計, q3 q7 q8 q11 q17 q19 q20 q22 q23 q27 q28 q34, output the form average marks of specific subject
           $sqlformteachskillavg = "SELECT AVG(q3), AVG(q7), AVG(q8), AVG(q11), AVG(q17), AVG(q19), AVG(q20), AVG(q22), AVG(q23), AVG(q27), AVG(q28), AVG(q34) FROM qrecords where class like '%$level%'"; 
           $resultformteachskillavg = mysqli_query($link, $sqlformteachskillavg);   
           $rowformteachskillavg = mysqli_fetch_array($resultformteachskillavg, MYSQLI_ASSOC);

           $formteachskillavgq3 = $rowformteachskillavg['AVG(q3)']; $formteachskillavgq7 = $rowformteachskillavg['AVG(q7)']; $formteachskillavgq8 = $rowformteachskillavg['AVG(q8)']; $formteachskillavgq11 = $rowformteachskillavg['AVG(q11)']; 
           $formteachskillavgq17 = $rowformteachskillavg['AVG(q17)']; $formteachskillavgq19 = $rowformteachskillavg['AVG(q19)'];$formteachskillavgq20 = $rowformteachskillavg['AVG(q20)']; $formteachskillavgq22 = $rowformteachskillavg['AVG(q22)']; 
           $formteachskillavgq23 = $rowformteachskillavg['AVG(q23)']; $formteachskillavgq27 = $rowformteachskillavg['AVG(q27)']; $formteachskillavgq28 = $rowformteachskillavg['AVG(q28)']; $formteachskillavgq34 = $rowformteachskillavg['AVG(q34)'];

           //Use the array variable $formteachskillavg[$no] to store the form teach skill average marks for all subjects in same level
           $formteachskillavg[$no] = ($formteachskillavgq3+$formteachskillavgq7+$formteachskillavgq8+$formteachskillavgq11+$formteachskillavgq17+$formteachskillavgq19+$formteachskillavgq20+$formteachskillavgq22+
           $formteachskillavgq23+$formteachskillavgq27+$formteachskillavgq28+$formteachskillavgq34)/12; //Fixed 12 questions for teaching skill
           
           $formteachskillavg_db = $formteachskillavg[$no];

           
           //Under testing, To get the average value of different question, 教學技巧[全校平均分]成績統計, q3 q7 q8 q11 q17 q19 q20 q22 q23 q27 q28 q34, output the whole school average marks of teaching skill
           $sqlschteachskillavg = "SELECT AVG(q3), AVG(q7), AVG(q8), AVG(q11), AVG(q17), AVG(q19), AVG(q20), AVG(q22), AVG(q23), AVG(q27), AVG(q28), AVG(q34) FROM qrecords"; 
           $resultschteachskillavg = mysqli_query($link, $sqlschteachskillavg);   
           $rowschteachskillavg = mysqli_fetch_array($resultschteachskillavg, MYSQLI_ASSOC);

           $schteachskillavgq3 = $rowschteachskillavg['AVG(q3)']; $schteachskillavgq7 = $rowschteachskillavg['AVG(q7)']; $schteachskillavgq8 = $rowschteachskillavg['AVG(q8)']; $schteachskillavgq11 = $rowschteachskillavg['AVG(q11)']; $schteachskillavgq17 = $rowschteachskillavg['AVG(q17)']; $schteachskillavgq19 = $rowschteachskillavg['AVG(q19)'];
           $schteachskillavgq20 = $rowschteachskillavg['AVG(q20)']; $schteachskillavgq22 = $rowschteachskillavg['AVG(q22)']; $schteachskillavgq23 = $rowschteachskillavg['AVG(q23)']; $schteachskillavgq27 = $rowschteachskillavg['AVG(q27)']; $schteachskillavgq28 = $rowschteachskillavg['AVG(q28)']; $schteachskillavgq34 = $rowschteachskillavg['AVG(q34)']; 

           //Use the array variable $subavg to store the self teach skill marks for all same subject group
           $schteachskillavg[$no] = ($schteachskillavgq3+$schteachskillavgq7+$schteachskillavgq8+$schteachskillavgq11+$schteachskillavgq17+$schteachskillavgq19+$schteachskillavgq20+$schteachskillavgq22
           +$schteachskillavgq23+$schteachskillavgq27+$schteachskillavgq28+$schteachskillavgq34)/12; //Fixed 12 questions for teaching skill

           $schteachskillavg_db =  $schteachskillavg[$no]; //copy the arrary variable to a varibale for write to the 'allreports' table
           //End of testing
              
           //To get the average value of different question, 教學效果[個人平均分]成績統計, q1 q2 q4	q5 q6 q10 q12 q13 q14 q15 q16 q18 q30 q31, output the personal average marks of specific subject
           $sqloutcome = "SELECT AVG(q1), AVG(q2), AVG(q4), AVG(q5), AVG(q6), AVG(q10), AVG(q12), AVG(q13), AVG(q14), AVG(q15), AVG(q16), AVG(q18), AVG(q30), AVG(q31) FROM qrecords where subjects = '$teachsub' AND class = '$grade'"; 
           $resultoutcome = mysqli_query($link, $sqloutcome);   
           $rowoutcome = mysqli_fetch_array($resultoutcome, MYSQLI_ASSOC);

           $avgq1 = $rowoutcome['AVG(q1)']; $avgq2 = $rowoutcome['AVG(q2)']; $avgq4 = $rowoutcome['AVG(q4)']; $avgq5 = $rowoutcome['AVG(q5)']; $avgq6 = $rowoutcome['AVG(q6)']; $avgq10 = $rowoutcome['AVG(q10)'];
           $avgq12 = $rowoutcome['AVG(q12)']; $avgq13 = $rowoutcome['AVG(q13)']; $avgq14 = $rowoutcome['AVG(q14)']; $avgq15 = $rowoutcome['AVG(q15)']; $avgq16 = $rowoutcome['AVG(q16)']; $avgq18 = $rowoutcome['AVG(q18)']; 
           $avgq30 = $rowoutcome['AVG(q30)']; $avgq31 = $rowoutcome['AVG(q31)'];

           $selfoutcome[$no]  = ($avgq1+$avgq2+$avgq4+$avgq5+$avgq6+$avgq10+$avgq12+$avgq13+$avgq14+$avgq15+$avgq16+$avgq18+$avgq30+$avgq31)/14; //Fixed 14 questions for teaching outcome store in the array variables 
           $selfoutcomeavg = $selfoutcome[$no]; //copy the arrary variable to a varibale for write to the 'allreports' table


           //Under testing, To get the average value of different question, 教學效果[全校平均分]成績統計, q1 q2 q4	q5 q6 q10 q12 q13 q14 q15 q16 q18 q30 q31, output the whole school average marks of specific questions
           $sqlschoutcomeavg = "SELECT AVG(q1), AVG(q2), AVG(q4), AVG(q5), AVG(q6), AVG(q10), AVG(q12), AVG(q13), AVG(q14), AVG(q15), AVG(q16), AVG(q18), AVG(q30), AVG(q31) FROM qrecords";
           $resultschoutcomeavg = mysqli_query($link, $sqlschoutcomeavg);
           $rowschoutcomeavg = mysqli_fetch_array($resultschoutcomeavg, MYSQLI_ASSOC);

           $schoutcomeavgq1 = $rowschoutcomeavg['AVG(q1)']; $schoutcomeavgq2 = $rowschoutcomeavg['AVG(q2)']; $schoutcomeavgq4 = $rowschoutcomeavg['AVG(q4)']; $schoutcomeavgq5 = $rowschoutcomeavg['AVG(q5)']; $schoutcomeavgq6 = $rowschoutcomeavg['AVG(q6)']; 
           $schoutcomeavgq10 = $rowschoutcomeavg['AVG(q10)'];$schoutcomeavgq12 = $rowschoutcomeavg['AVG(q12)']; $schoutcomeavgq13 = $rowschoutcomeavg['AVG(q13)']; $schoutcomeavgq14 = $rowschoutcomeavg['AVG(q14)']; $schoutcomeavgq15 = $rowschoutcomeavg['AVG(q15)'];
           $schoutcomeavgq16 = $rowschoutcomeavg['AVG(q16)']; $schoutcomeavgq18 = $rowschoutcomeavg['AVG(q18)']; $schoutcomeavgq30 = $rowschoutcomeavg['AVG(q30)']; $schoutcomeavgq31 = $rowschoutcomeavg['AVG(q31)'];

           //Fixed 14 questions for whole school teaching outcome store in the array variables
           $schoutcomeavg[$no]  = ($schoutcomeavgq1+$schoutcomeavgq2+$schoutcomeavgq4+$schoutcomeavgq5+$schoutcomeavgq6+$schoutcomeavgq10+$schoutcomeavgq12+$schoutcomeavgq13+$schoutcomeavgq14+$schoutcomeavgq15
           +$schoutcomeavgq16+$schoutcomeavgq18+$schoutcomeavgq30+$schoutcomeavgq31)/14; 

           $schoutcomeavg_db = $schoutcomeavg[$no]; //copy the arrary variable to a variable for write to the 'allreports' table
           //end of testing


           //To get the average value of different question, 教學效果[科組平均分]成績統計, q1 q2 q4	q5 q6 q10 q12 q13 q14 q15 q16 q18 q30 q31, output the same subject group average marks of specific subject
           $sqlsuboutcome = "SELECT AVG(q1), AVG(q2), AVG(q4), AVG(q5), AVG(q6), AVG(q10), AVG(q12), AVG(q13), AVG(q14), AVG(q15), AVG(q16), AVG(q18), AVG(q30), AVG(q31) FROM qrecords where subjects = '$teachsub'"; 
           $resultsuboutcome = mysqli_query($link, $sqlsuboutcome);   
           $rowsuboutcome = mysqli_fetch_array($resultsuboutcome, MYSQLI_ASSOC);

           $suboutcomeq1 = $rowsuboutcome['AVG(q1)']; $suboutcomeq2 = $rowsuboutcome['AVG(q2)']; $suboutcomeq4 = $rowsuboutcome['AVG(q4)']; $suboutcomeq5 = $rowsuboutcome['AVG(q5)']; $suboutcomeq6 = $rowsuboutcome['AVG(q6)']; $suboutcomeq10 = $rowsuboutcome['AVG(q10)'];
           $suboutcomeq12 = $rowsuboutcome['AVG(q12)']; $suboutcomeq13 = $rowsuboutcome['AVG(q13)']; $suboutcomeq14 = $rowsuboutcome['AVG(q14)']; $suboutcomeq15 = $rowsuboutcome['AVG(q15)']; $suboutcomeq16 = $rowsuboutcome['AVG(q16)']; $suboutcomeq18 = $rowsuboutcome['AVG(q18)']; 
           $suboutcomeq30 = $rowsuboutcome['AVG(q30)']; $suboutcomeq31 = $rowsuboutcome['AVG(q31)'];

           //Fixed 14 questions for teaching outcome store in the array variables
           $suboutcome[$no]  = ($suboutcomeq1+$suboutcomeq2+$suboutcomeq4+$suboutcomeq5+$suboutcomeq6+$suboutcomeq10+$suboutcomeq12+$suboutcomeq13+$suboutcomeq14+$suboutcomeq15+$suboutcomeq16+$suboutcomeq18
           +$suboutcomeq30+$suboutcomeq31)/14; 
           $suboutcomeavg = $suboutcome[$no]; //copy the arrary variable to a variable for write to the 'allreports' table 



           //To get the average value of different question, 教學效果[班級平均分]成績統計, q1 q2 q4	q5 q6 q10 q12 q13 q14 q15 q16 q18 q30 q31, output the same subject group average marks of specific subject
           $sqlformoutcomeavg = "SELECT AVG(q1), AVG(q2), AVG(q4), AVG(q5), AVG(q6), AVG(q10), AVG(q12), AVG(q13), AVG(q14), AVG(q15), AVG(q16), AVG(q18), AVG(q30), AVG(q31) FROM qrecords where class like '%$level%'"; 
           $resultformoutcomeavg = mysqli_query($link, $sqlformoutcomeavg);   
           $rowformoutcomeavg = mysqli_fetch_array($resultformoutcomeavg, MYSQLI_ASSOC);

           $formoutcomeavgq1 = $rowformoutcomeavg['AVG(q1)']; $formoutcomeavgq2 = $rowformoutcomeavg['AVG(q2)']; $formoutcomeavgq4 = $rowformoutcomeavg['AVG(q4)']; $formoutcomeavgq5 = $rowformoutcomeavg['AVG(q5)']; $formoutcomeavgq6 = $rowformoutcomeavg['AVG(q6)']; $formoutcomeavgq10 = $rowformoutcomeavg['AVG(q10)'];
           $formoutcomeavgq12 = $rowformoutcomeavg['AVG(q12)']; $formoutcomeavgq13 = $rowformoutcomeavg['AVG(q13)']; $formoutcomeavgq14 = $rowformoutcomeavg['AVG(q14)']; $formoutcomeavgq15 = $rowformoutcomeavg['AVG(q15)']; $formoutcomeavgq16 = $rowformoutcomeavg['AVG(q16)']; $formoutcomeavgq18 = $rowformoutcomeavg['AVG(q18)']; 
           $formoutcomeavgq30 = $rowformoutcomeavg['AVG(q30)']; $formoutcomeavgq31 = $rowformoutcomeavg['AVG(q31)'];

           //Fixed 14 questions for teaching outcome store in the array variables
           $formoutcomeavg[$no]  = ($formoutcomeavgq1+$formoutcomeavgq2+$formoutcomeavgq4+$formoutcomeavgq5+$formoutcomeavgq6+$formoutcomeavgq10+$formoutcomeavgq12+$formoutcomeavgq13+$formoutcomeavgq14+$formoutcomeavgq15+$formoutcomeavgq16+$formoutcomeavgq18
           +$formoutcomeavgq30+$formoutcomeavgq31)/14; 

           $formoutcomeavg_db = $formoutcomeavg[$no]; //copy the arrary variable $formoutcomeavg[$no] to a variable for write to the 'allreports' table 




           //To get the average value of different question, 教學態度[個人平均分] questions 9, 21, 24, 25, 26, 29, 32, 33
           $sqlattitude = "SELECT AVG(q9), AVG(q21), AVG(q24), AVG(q25), AVG(q26), AVG(q29), AVG(q32), AVG(q33) FROM qrecords where subjects = '$teachsub' AND class = '$grade'"; 
           $resultattitude = mysqli_query($link, $sqlattitude);   
           $rowattitude = mysqli_fetch_array($resultattitude, MYSQLI_ASSOC);
            
           $avgq9 = $rowattitude['AVG(q9)']; $avgq21 = $rowattitude['AVG(q21)']; $avgq24 = $rowattitude['AVG(q24)']; $avgq25 = $rowattitude['AVG(q25)']; $avgq26 = $rowattitude['AVG(q26)']; $avgq29 = $rowattitude['AVG(q29)'];
           $avgq32 = $rowattitude['AVG(q32)']; $avgq33 = $rowattitude['AVG(q33)'];

           $selfattitude[$no] = ($avgq9+$avgq21+$avgq24+$avgq25+$avgq26+$avgq29+$avgq32+$avgq33)/8; //Fixed 8 questions for teaching attitude store in the array variables



           //Under testing, To get the average value of different question, 教學態度[全校平均分] questions 9, 21, 24, 25, 26, 29, 32, 33
           $sqlschattitudeavg = "SELECT AVG(q9), AVG(q21), AVG(q24), AVG(q25), AVG(q26), AVG(q29), AVG(q32), AVG(q33) FROM qrecords"; 
           $resultsattitudeavg = mysqli_query($link, $sqlschattitudeavg);   
           $rowschattitudeavg = mysqli_fetch_array($resultsattitudeavg, MYSQLI_ASSOC);

           $schattitudeavgq9 = $rowschattitudeavg['AVG(q9)']; $schattitudeavgq21 = $rowschattitudeavg['AVG(q21)']; $schattitudeavgq24 = $rowschattitudeavg['AVG(q24)']; $schattitudeavgq25 = $rowschattitudeavg['AVG(q25)']; 
           $schattitudeavgq26 = $rowschattitudeavg['AVG(q26)']; $schattitudeavgq29 = $rowschattitudeavg['AVG(q29)']; $schattitudeavgq32 = $rowschattitudeavg['AVG(q32)']; $schattitudeavgq33 = $rowschattitudeavg['AVG(q33)'];

           //Fixed 8 questions for whole school teaching attitude store in the array variables
           $schattitudeavg[$no] = ($schattitudeavgq9+$schattitudeavgq21+$schattitudeavgq24+$schattitudeavgq25+$schattitudeavgq26+$schattitudeavgq29+$schattitudeavgq32+$schattitudeavgq33)/8;     
           $schattitudeavg_db = $schattitudeavg[$no]; //Assign array variable $schattitudeavg[$no] to store 教學態度[全校平均分] into the table "allreports"

           
           //To get the average value of different question, 教學態度[科組平均分] questions 9, 21, 24, 25, 26, 29, 32, 33
           $sqlsubattitude = "SELECT AVG(q9), AVG(q21), AVG(q24), AVG(q25), AVG(q26), AVG(q29), AVG(q32), AVG(q33) FROM qrecords where subjects = '$teachsub'"; 
           $resultsubattitude = mysqli_query($link, $sqlsubattitude);   
           $rowsubattitude = mysqli_fetch_array($resultsubattitude, MYSQLI_ASSOC);
            
           $subattitudeq9 = $rowsubattitude['AVG(q9)']; $subattitudeq21 = $rowsubattitude['AVG(q21)']; $subattitudeq24 = $rowsubattitude['AVG(q24)']; $subattitudeq25 = $rowsubattitude['AVG(q25)']; $subattitudeq26 = $rowsubattitude['AVG(q26)']; $subattitudeq29 = $rowsubattitude['AVG(q29)'];
           $subattitudeq32 = $rowsubattitude['AVG(q32)']; $subattitudeq33 = $rowsubattitude['AVG(q33)'];

           $subattitude[$no] = ($subattitudeq9+$subattitudeq21+$subattitudeq24+$subattitudeq25+$subattitudeq26+$subattitudeq29+$subattitudeq32+$subattitudeq33)/8; //Fixed 8 questions for teaching attitude store in the array variables
                     
           $subattitude_db = $subattitude[$no]; 
           
           
           $subjectitems[$no] = $teachsub; //Use the array variable $subjectitems to store the teach subject


           //Under testing, To get the average value of different question, 教學態度[班級平均分] questions 9, 21, 24, 25, 26, 29, 32, 33
           $sqlformattitudeavg = "SELECT AVG(q9), AVG(q21), AVG(q24), AVG(q25), AVG(q26), AVG(q29), AVG(q32), AVG(q33) FROM qrecords where class like '%$level%'"; 
           $resultformattitudeavg = mysqli_query($link, $sqlformattitudeavg);   
           $rowformattitudeavg = mysqli_fetch_array($resultformattitudeavg, MYSQLI_ASSOC);
            
           $formattitudeavgq9 = $rowformattitudeavg['AVG(q9)']; $formattitudeavgq21 = $rowformattitudeavg['AVG(q21)']; $formattitudeavgq24 = $rowformattitudeavg['AVG(q24)']; 
           $formattitudeavgq25 = $rowformattitudeavg['AVG(q25)']; $formattitudeavgq26 = $rowformattitudeavg['AVG(q26)']; $formattitudeavgq29 = $rowformattitudeavg['AVG(q29)'];
           $formattitudeavgq32 = $rowformattitudeavg['AVG(q32)']; $formattitudeavgq33 = $rowformattitudeavg['AVG(q33)'];

           $formattitudeavg[$no] = ($formattitudeavgq9+$formattitudeavgq21+$formattitudeavgq24+$formattitudeavgq25+$formattitudeavgq26+$formattitudeavgq29+$formattitudeavgq32+$formattitudeavgq33)/8; //Fixed 8 questions for teaching attitude store in the array variables                     
           
           $formattitudeavg_db = $formattitudeavg[$no];
           
           $no += 1; //Add 1 for array each time 
           $countsub += 1; //Add 1 for each time, count the number of subject    

           //Insert or update four data of "teach skill" included "selfavg", "schavg", "subavg" and "classavg"
           $sqlteachskill = "SELECT * FROM allreports where tsname = '$teacher' and tsclass = '$grade' and  subjects = '$teachsub' and assessitem = '教學技巧'";
           $resultteachskill = $link->query($sqlteachskill);

           if ($resultteachskill->num_rows > 0) {            
            $sqlteachskill = "UPDATE allreports SET selfavg='$selfteachavg', schavg='0', subavg='$subjectavg', classavg='0' WHERE tsname = '$teacher' and subjects = '$teachsub' and tsclass = '$grade' and assessitem = '教學技巧' ";            
           }      
           if ($resultteachskill->num_rows == 0) {
            $sqlteachskill = "INSERT INTO allreports (tsname, tsclass, subjects, assessitem, selfavg, schavg, subavg, classavg) VALUES ('$teacher', '$grade', '$teachsub', '教學技巧', '$selfteachavg', '0', '$subjectavg','0')";
           }
           $resultteachskill = $link->query($sqlteachskill);        
           //End of Insert or update four data of teach skill included "selfavg", "schavg", "subavg" and "classavg"

           
           //Insert or update four data of "teach outcome" included "selfavg", "schavg", "subavg" and "classavg"
           $sqlteachoutcome = "SELECT * FROM allreports where tsname = '$teacher' and tsclass = '$grade' and  subjects = '$teachsub' and assessitem = '教學效果'";
           $resultteachoutcome = $link->query($sqlteachoutcome);

           if ($resultteachoutcome->num_rows > 0) {            
            $sqlteachoutcome = "UPDATE allreports SET selfavg='$selfoutcomeavg', schavg='0', subavg='$suboutcomeavg', classavg='0' WHERE tsname = '$teacher' and subjects = '$teachsub' and tsclass = '$grade' and assessitem = '教學效果' ";            
           }      
           if ($resultteachoutcome->num_rows == 0) {
            $sqlteachoutcome = "INSERT INTO allreports (tsname, tsclass, subjects, assessitem, selfavg, schavg, subavg, classavg) VALUES ('$teacher', '$grade', '$teachsub', '教學效果', '$selfoutcomeavg', '0', '$suboutcomeavg','0')";
           }
           $resultteachoutcome = $link->query($sqlteachoutcome);        
           //End of Insert or update four data of "teach outcome" included "selfavg", "schavg", "subavg" and "classavg"









           /*Count the field(S) for one subject in DB table, useful codes
           $sqlcountrec = "SELECT COUNT(q3) FROM qrecords WHERE subjects = '$teachsub' AND class = '$grade'";
           $resultcountrec = mysqli_query($link, $sqlcountrec);   
            $rowcount = mysqli_fetch_array($resultcountrec, MYSQLI_ASSOC);
           $countrec = $rowcount['COUNT(q3)'];
           */
           
           } //End of do while          
 
        } //End if the table exist record(s)
           
        else  //else if num_rows is equal to 0
        {
          //If the table is empty
          echo "<BR>這位老師沒有任教任何科目 !";
        } 
     
                      
        //echo " Max array no. : " .$no;
        
        if ($countsub != 0)  //Check if the teacher teach at least one subject then below "while loop" codes will execute
        {

        echo "任教科目的數目: " .$countsub;   //echo round($number, 2);       
        
        $whileno = 1; //The start value of the while loop  
        do {
                  
           echo "<BR><table style='width: 826px; height: 92px;' border='2' align='left' cellpadding='2' cellspacing='2'>";
           echo "<tbody>";
           echo "<tr><td><B><font color='blue'>" .$subjectitems[$whileno]. " [" .$grades[$whileno]. "] " . "</font></B><br></td>";
           echo "<td><strong>個人平均分<br></strong></td>";
           echo "<td><strong>全校平均分<br></strong></td>";
           echo "<td><strong>科組平均分<br></strong></td>";
           echo "<td><strong>班級平均分<br></strong></td></tr>";
           echo "<tr><td><strong>教學技巧<br></strong></td>";
           echo "<td>" .round($selfteachskill[$whileno],2). "</td><td>" .round($schteachskillavg[$whileno],2). "</td><td>" .round($subavg[$whileno],2). "</td><td style='width: 148.783px;'>" .round($formteachskillavg[$whileno],2). "</td></tr>";

           echo "<tr><td style='width: 163.467px;'><strong>教學效果<br></strong></td>";
           echo "<td style='width: 161.05px;'>" .round($selfoutcome[$whileno],2). "</td>";         
           echo "<td style='width: 167.8px;'>" .round($schoutcomeavg[$whileno],2). "</td>";
           echo "<td style='width: 151.15px;'>" .round($suboutcome[$whileno],2). "</td>";
           echo "<td>" .round($formoutcomeavg[$whileno],2). "</td></tr>";

           echo "<tr><td><strong>教學態度<br></strong></td>";
           echo "<td>" .round($selfattitude[$whileno],2). "</td><td>" .round($schattitudeavg[$whileno],2). "</td><td>" .round($subattitude[$whileno],2). "</td><td>" .round($formattitudeavg[$whileno]). "</td></tr>";
           echo "</tbody>";
           echo "</table><BR><BR><BR><BR><BR><BR><BR>";
           $whileno++;
        
        } while ($whileno <= $countsub);
    
    if (mysqli_query($link, $sqladmin)) {    } else { echo "SQL query for login name and pin failure ! " . $sqladmin . "<br>" . mysqli_error($link);}


  
    } //End if the number of teach subject equal to zero



    //Under testing
    //Below show the table of 個人總覧
    echo "<H2>老師個人總覧:</H2><BR>";
    echo "<table width='100%' style='text-align:' left; border='1' cellpadding='2' cellspacing='2'>";
    echo "<tr>";
    echo "<td width='100'><B>科目</B></td><td><B>班別</B></td><td><B>Q1</B></td><td ><B>Q2</B></td><td ><B>Q3</B></td><td ><B>Q4</B></td><td ><B>Q5</B></td><td ><B>Q6</B></td>";
    echo "<td ><B>Q7</B></td><td ><B>Q8</B></td><td ><B>Q9</B></td><td ><B>Q10</B></td><td ><B>Q11</B></td><td ><B>Q12</B></td><td ><B>Q13</B></td><td ><B>Q14</B></td><td ><B>Q15</B></td><td ><B>Q16</B></td>";
    echo "<td ><B>Q17</B></td><td ><B>Q18</B></td><td ><B>Q19</B></td><td ><B>Q20</B></td><td ><B>Q21</B></td><td ><B>Q22</B></td><td ><B>Q23</B></td><td ><B>Q24</B></td><td ><B>Q25</B></td><td ><B>Q26</B></td>";
    echo "<td ><B>Q27</B></td><td ><B>Q28</B></td><td ><B>Q29</B></td><td ><B>Q30</B></td><td ><B>Q31</B></td><td ><B>Q32</B></td><td ><B>Q33</B></td><td ><B>Q34</B></td><td ><B>Q35</B></td><td ><B>Q36</B></td>";
    echo "<td ><B>Q37</B></td><td ><B>Q38</B></td><td ><B>Q39</B></td><td ><B>Q40</B></td><td ><B>Q41</B><td ><B>平均分</B></td>";
    echo "</tr>";
    
    //After insert a set of new data to the table, read the all records from the table
    $sqlteacher = "SELECT * FROM teachers where teacher1 = '$teacher' OR teacher2 = '$teacher' OR teacher3 = '$teacher' OR teacher4 = '$teacher' OR teacher5 = '$teacher' OR teacher6 = '$teacher' OR 
    teacher7 = '$teacher' OR teacher8 = '$teacher' OR teacher9 = '$teacher' OR teacher10 = '$teacher' OR teacher11 = '$teacher' OR teacher12 = '$teacher' OR teacher13 = '$teacher' OR teacher14 = '$teacher' 
    OR teacher15 = '$teacher'";
        
    $result0 = $link->query($sqlteacher);  

    if ($result0->num_rows > 0) {    
           
        while($row01 = $result0->fetch_assoc()) {

           //Find the teacher teach the subject and class row by row in the DB table "teachers"
           $grade = $row01['grade'];
           $teachsub = $row01['teachsub'];

           //$sqlaccess = "SELECT SUM(q1), SUM(q2), SUM(q3), SUM(q4), SUM(q5), SUM(q6), SUM(q7), SUM(q8), SUM(q9), SUM(q10), SUM(q11), SUM(q12), SUM(q13), SUM(q14), SUM(q15), SUM(q16), SUM(q17), SUM(q18), SUM(q19), SUM(q20), SUM(q21), SUM(q22), SUM(q23), SUM(q24), SUM(q25), SUM(q26), SUM(q27), SUM(q28), SUM(q29), SUM(q30), SUM(q31), SUM(q32), SUM(q33), SUM(q34), SUM(q35), SUM(q36), SUM(q37), SUM(q38), SUM(q39), SUM(q40), SUM(q41) FROM qrecords WHERE subjects = '$teachsub' AND class = '$grade'";
           $sqlaccess = "SELECT AVG(q1), AVG(q2), AVG(q3), AVG(q4), AVG(q5), AVG(q6), AVG(q7), AVG(q8), AVG(q9), AVG(q10), AVG(q11), AVG(q12), AVG(q13), AVG(q14), AVG(q15), AVG(q16), AVG(q17), AVG(q18), AVG(q19), AVG(q20), AVG(q21), AVG(q22), AVG(q23), AVG(q24), AVG(q25), AVG(q26), AVG(q27), AVG(q28), AVG(q29), AVG(q30), AVG(q31), AVG(q32), AVG(q33), AVG(q34), AVG(q35), AVG(q36), AVG(q37), AVG(q38), AVG(q39), AVG(q40), AVG(q41) FROM qrecords WHERE subjects = '$teachsub' AND class = '$grade'";
           $resultinfo = mysqli_query($link, $sqlaccess);  
           $rowno = mysqli_fetch_array($resultinfo, MYSQLI_ASSOC);         
           
           
           // Under testing, round the values to two digits 
           echo "<tr><td><b>" .$teachsub. "</b></td><td><b>" .$grade. "</b></td><td><b>" .round($rowno['AVG(q1)'],2). "</b></td><td><b>" .round($rowno['AVG(q2)'],2). "</b></td><td><b>" .round($rowno['AVG(q3)'],2). "</b></td><td><b>" .round($rowno['AVG(q4)'],2). "</b></td><td><b>" .round($rowno['AVG(q5)'],2). "</b></td><td><b>" .round($rowno['AVG(q6)'],2). "</b></td><td><b>"
           .round($rowno['AVG(q7)'],2). "</b></td><td><b>" .round($rowno['AVG(q8)'],2). "</b></td><td><b>" .round($rowno['AVG(q9)'],2). "</b></td><td><b>" .round($rowno['AVG(q10)'],2). "</b></td><td><b>" .round($rowno['AVG(q11)'],2). "</b></td><td><b>" .  round($rowno['AVG(q12)'],2). "</b></td><td><b>" .round($rowno['AVG(q13)'],2). "</b></td><td><b>" .round($rowno['AVG(q14)'],2). 
           "</b></td><td><b>" .round($rowno['AVG(q15)'],2). "</b></td><td><b>" .round($rowno['AVG(q16)'],2). "</b></td><td><b>" .round($rowno['AVG(q17)'],2). "</b></td><td><b>" .round($rowno['AVG(q18)'],2). "</b></td><td><b>" .round($rowno['AVG(q19)'],2). "</b></td><td><b>" .round($rowno['AVG(q20)'],2). "</b></td>" . "<td><b>" .round($rowno['AVG(q21)'],2). "</b></td>" . "<td><b>"
            .round($rowno['AVG(q22)'],2). "</b></td>" . "<td><b>" .  round($rowno['AVG(q23)'],2). "</b></td>" . "<td><b>" .round($rowno['AVG(q24)'],2). "</b></td>" . "<td><b>" .round($rowno['AVG(q25)'],2). "</b></td>" . "<td><b>" .round($rowno['AVG(q26)'],2). "</b></td>" . "<td><b>" .round($rowno['AVG(q27)'],2). "</b></td>" . "<td><b>" .round($rowno['AVG(q28)'],2). "</b></td>". 
            "<td><b>" .round($rowno['AVG(q29)'],2). "</b></td>" . "<td><b>" .round($rowno['AVG(q30)'],2). "</b></td>" . "<td><b>" .round($rowno['AVG(q31)'],2). "</b></td>" . "<td><b>" .round($rowno['AVG(q32)'],2). "</b></td>" . "<td><b>" .round($rowno['AVG(q33)'],2). "</b></td>" . "<td><b>" .round($rowno['AVG(q34)'],2). "</b></td>" . "<td><b>" . round($rowno['AVG(q35)'],2). "</b></td>"
             . "<td><b>" .round($rowno['AVG(q36)'],2). "</b></td>" . "<td><b>" .round($rowno['AVG(q37)'],2). "</b></td>" . "<td><b>" .round($rowno['AVG(q38)'],2). "</b></td>" . "<td><b>" .round($rowno['AVG(q39)'],2). "</b></td>" . "<td><b>" . round($rowno['AVG(q40)'],2). "</b></td>" . "<td><b>" . round($rowno['AVG(q41)'],2). "</b></td>" . "<td><b>" . "備用". "</b></td></tr>";            
        
           /* Run Ok.   
           echo "<tr><td><b>" .$teachsub. "</b></td><td><b>" .$grade. "</b></td><td><b>" .round($rowno['AVG(q1)'],2). "</b></td><td><b>" .round($rowno['AVG(q2)'],2). "</b></td><td><b>" .round($rowno['AVG(q3)'],2). "</b></td><td><b>" .  $rowno['AVG(q4)']. "</b></td><td><b>" .  $rowno['AVG(q5)']. "</b></td><td><b>" .  $rowno['AVG(q6)']. "</b></td><td><b>"
           .  $rowno['AVG(q7)']. "</b></td><td><b>" .  $rowno['AVG(q8)']. "</b></td><td><b>" .$rowno['AVG(q9)']. "</b></td><td><b>" .  $rowno['AVG(q10)']. "</b></td><td><b>" .  $rowno['AVG(q11)']. "</b></td><td><b>" .  $rowno['AVG(q12)']. "</b></td><td><b>" .  $rowno['AVG(q13)']. "</b></td><td><b>" .  $rowno['AVG(q14)']. 
           "</b></td><td><b>" .  $rowno['AVG(q15)']. "</b></td><td><b>" .  $rowno['AVG(q16)']. "</b></td><td><b>" .  $rowno['AVG(q17)']. "</b></td><td><b>" .  $rowno['AVG(q18)']. "</b></td><td><b>" .  $rowno['AVG(q19)']. "</b></td><td><b>" .  $rowno['AVG(q20)']. "</b></td>" . "<td><b>" .  $rowno['AVG(q21)']. "</b></td>" . "<td><b>"
            .  $rowno['AVG(q22)']. "</b></td>" . "<td><b>" .  $rowno['AVG(q23)']. "</b></td>" . "<td><b>" .  $rowno['AVG(q24)']. "</b></td>" . "<td><b>" .  $rowno['AVG(q25)']. "</b></td>" . "<td><b>" .  $rowno['AVG(q26)']. "</b></td>" . "<td><b>" .  $rowno['AVG(q27)']. "</b></td>" . "<td><b>" .  $rowno['AVG(q28)']. "</b></td>". 
            "<td><b>" . $rowno['AVG(q29)']. "</b></td>" . "<td><b>" . $rowno['AVG(q30)']. "</b></td>" . "<td><b>" . $rowno['AVG(q31)']. "</b></td>" . "<td><b>" . $rowno['AVG(q32)']. "</b></td>" . "<td><b>" . $rowno['AVG(q33)']. "</b></td>" . "<td><b>" . $rowno['AVG(q34)']. "</b></td>" . "<td><b>" . $rowno['AVG(q35)']. "</b></td>"
             . "<td><b>" . $rowno['AVG(q36)']. "</b></td>" . "<td><b>" . $rowno['AVG(q37)']. "</b></td>" . "<td><b>" . $rowno['AVG(q38)']. "</b></td>" . "<td><b>" . $rowno['AVG(q39)']. "</b></td>" . "<td><b>" . $rowno['AVG(q40)']. "</b></td>" . "<td><b>" . $rowno['AVG(q41)']. "</b></td>" . "<td><b>" . "備用". "</b></td></tr>";      
           */
        
        }
    }
    
    echo "<tr><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td>
    <td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td> <td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td>
    <td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td> <td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b></b></td><td><b>總分</b></td><td><b>" .$totalmarks. "</b></td></tr>";           
        
    echo"</tbody>";
    echo "</table><BR>";


    //Under testing of 個人總覧
    //Under testing, read the specific teacher introinspection contents
    $sqlreadreflect = "select *from gslcteacher where tname = '$teacher'";
    $resultreadreflect = mysqli_query($link, $sqlreadreflect);  
    $rowreadreflect = mysqli_fetch_array($resultreadreflect, MYSQLI_ASSOC);  
   
    $reflectcontent = $rowreadreflect['introspection']; //Read the contents of introspection for specific teacher
    $notsubmit =$rowreadreflect['nosubmit'];  //Read the field of "nosubmit" for check whether the teacher submitted the introinpsection

    echo "<table width = '100%' style='text-align:' left; border='1' cellpadding='2' cellspacing='2' background='images/reflect_wall.png'>";
    echo "<tr><td><H3><B>教與學反思內容:</B><BR></H3>" .$reflectcontent . "</td></tr>";
    echo "</table><BR><BR>";
    //End of testing

    //close the connection 
    mysqli_close($link);
    }//End of check teacher name and password
    else
    {         
    echo "<center><div style='border:2px #ccc solid;border-radius:20px;width:360px;height:500px;background-color:#ffffff;border-width:5px;padding:1px; box-shadow: 2px 2px 2px 1px rgba(0, 0, 0, 0.5);'>
    <center><img src = 'images/loginfail.jpg'></center><BR><center><H2>登入名稱或密碼有錯，請重試 !</H2><BR><BR><BR></center><center><h2><a href='qform_login.html'>回到登入畫面</a><h2></center></div></center>";             
    }


    //Under testing, read the field "nosubmit", no show the textarea if the variable $notsubmit equal to zero means the teacher submitted the introinspection
    if ($notsubmit == 1 && $cookiename != "teacher"){
        echo "老師請在以下的文字方塊輸入反思內容，只可以輸入一次，存檔後不可以修改。(850字上限)<BR>";
        echo"<form name='reflectform' action='reflectupdate.php' onsubmit='return validateForm()' method='post' >";  
        echo "<textarea name='reflection' rows='8' cols='150'></textarea><BR>";
        echo "<input value='送出資料' name='submit' type='submit'>";
        echo"</form><br>";
    }
    if ($notsubmit != 1 && $cookiename != "teacher")
    {
        echo "<H2>你已提交了反思報告，不能再次提交，謝謝。</H2>";
    }


    echo "<BR><a href='logout.php'><B>登出系統</B></a>";

    echo "<table width='100%' border='0'>";
    echo "<tr>";
    echo "<td height='50' colspan='2' background='images/titlebrick.jpg'><center>";
    echo "<p><font color = 'white'><strong>Copyright © 2021 路德會西門英才中學. All Rights Reserved.</strong></font></p>";
    echo "</center></td>";
    echo "</tr>";
    echo "</table>";

    
    
    //Clear the cookies in the memory
    unset($cookiename);  //clear the login name  
    unset($cookiepin);  //Clear the password
    
?>